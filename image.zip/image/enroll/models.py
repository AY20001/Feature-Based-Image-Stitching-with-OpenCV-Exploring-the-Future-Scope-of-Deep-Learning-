from django.db import models


class User(models.Model):
    username = models.CharField(max_length=80)
    fname = models.CharField(max_length=89)
    lname = models.CharField(max_length=88)
    email = models.EmailField(max_length=90)
    pass1 = models.CharField(max_length=90)
    pass2 = models.CharField(max_length=90)

class ImageUpload(models.Model):
    original_images = models.ManyToManyField('UploadedImage', related_name='uploads')
    generated_image = models.ImageField(upload_to='generated_images/')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image Upload {self.id} - {self.created_at}"
        
class UploadedImage(models.Model):
    image = models.ImageField(upload_to='original_images/')
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Image {self.id} - {self.uploaded_at}"
