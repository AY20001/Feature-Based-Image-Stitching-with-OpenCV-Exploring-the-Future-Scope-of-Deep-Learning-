from django.contrib import admin
from django.urls import path, include

from django.conf import settings
from django.conf.urls.static import static
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from . import views

urlpatterns = [
      path('', views.index, name='index'),

      path('signup/', views.signupuser, name="signup"),
      path('login/', views.loginuser, name="login"),
      path('logout/', views.logoutuser, name="logout"),

      path('home/', views.home, name='home'),
      path('users/', views.users, name='users'),
      path('about/', views.about, name='about'),
      path('upload_images/',views.image_upload,name="upload_images"),
      path('final_image/', views.final_image, name="final_image"),
      path('delete_images/', views.delete_images, name='delete_images'),
        

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
urlpatterns += staticfiles_urlpatterns()