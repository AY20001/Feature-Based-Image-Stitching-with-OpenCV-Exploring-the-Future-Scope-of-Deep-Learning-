from django.shortcuts import render

# Create your views here.
from django.shortcuts import render

# Create your views here.
import json
from django.shortcuts import render, redirect
from .models import *
from django.contrib import messages
# import numpy as np
# import pandas as pd
import pickle
from django.http import  JsonResponse
from django.core.files.storage import default_storage




# Create your views here.

def index(request):
    return render(request, 'index.html')


def about(request):
    return render(request, 'about.html')


def signupuser(request):
    if request.method == 'POST':
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        if pass1 != pass2:
            messages.error(request, "password do not match")
            return redirect('signup')

        # Check if the username and email are unique
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")
            return redirect('signup')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered.")
            return redirect('signup')

        else:
            # Create a new User object and save it
            user = User(username=username, fname=fname, lname=lname, email=email, pass1=pass1, pass2=pass2)
            user.save()

        # Redirect to the login page after successful registration
        messages.error(request, f"Hello {username}, You are registered successfully")
        return redirect('login')
    else:
        return render(request, 'signup.html')


def loginuser(request):
    if request.method == 'POST':
        username = request.POST['username']
        pass1 = request.POST['pass1']

        user = User.objects.filter(username=username, pass1=pass1).first()
        if user:
            # Set the User ID in the session to keep the User logged in
            request.session['User_id'] = user.id
            messages.error(request, "Logged in successfully")
            return redirect('home')

        user = User.objects.filter(email=username, pass1=pass1).first()
        if user:
            # Set the User ID in the session to keep the User logged in
            request.session['User_id'] = user.id
            messages.error(request, "Logged in Successfully")
            return redirect('home')

        return render(request, 'login.html', {'error': 'Invalid Email/Username or password'})

    # return render(request, 'login.html')
    return render(request, 'login.html')


def logoutuser(request):
    request.session.flush()  # Ends the session and clears all session data
    messages.success(request, "Successfully logged out!")
    return redirect('index')  # Redirects to the URL named 'index'


def home(request):
    user_id = request.session.get('User_id')
    user = User.objects.get(id=user_id)
    fname = user.fname
    return render(request, 'home.html', {'fname': fname.capitalize()})


def users(request):
    obj = User.objects.all()
    context = {
        'obj': obj
    }
    return render(request, 'users.html', context)

def image_upload(request):
    if request.method == 'POST' and request.FILES.getlist('images'):
        upload_folder = "OriginalImages"
        os.makedirs(upload_folder, exist_ok=True)

        for img in request.FILES.getlist('images'):
            file_path = os.path.join(upload_folder, img.name)
            with default_storage.open(file_path, 'wb+') as destination:
                for chunk in img.chunks():
                    destination.write(chunk)

        messages.success(request, "Images uploaded successfully.")
        stitch()
        return render(request,'wait.html')
    

    return render(request, 'upload_images.html')


import stitching
import os

import os
import cv2
import numpy as np

def stitch(folder_path="OriginalImages"):
    # Get all image file paths from the folder
    image_extensions = ('.jpg', '.jpeg', '.png', '.bmp', '.tiff')
    image_paths = [os.path.join(folder_path, file) for file in sorted(os.listdir(folder_path)) if file.lower().endswith(image_extensions)]

    if len(image_paths) < 2:
        raise ValueError("The folder must contain at least two image files for stitching.")

    # Initialize the stitcher with settings
    stitcher = stitching.Stitcher()
    
    # Perform image stitching
    panorama = stitcher.stitch(image_paths)

    if panorama is None:
        raise RuntimeError("Image stitching failed. Please check input images.")

    # Ensure output directory exists
    output_folder = "generated_image"
    os.makedirs(output_folder, exist_ok=True)
    
    # Save the stitched image
    output_path = os.path.join(output_folder, "final.png")
    cv2.imwrite(output_path, panorama)  # Correct method to save an image
    

def final_image(request):
    image_path = "/generated_image/final.png"  # Relative path to the saved image
    return render(request, 'output.html', {'image_url': image_path})

# In your views.py file
import os
import shutil
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt  # Exempt CSRF check for this endpoint if needed
def delete_images(request):
    if request.method == 'POST':
        # Define the directories
        generated_folder = "generated_image"
        original_folder = "OriginalImages"

        # Function to delete all files in a folder
        def delete_files_from_folder(folder):
            for file_name in os.listdir(folder):
                file_path = os.path.join(folder, file_name)
                try:
                    if os.path.isfile(file_path):
                        os.remove(file_path)  # Delete file
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)  # Delete folder (if it's a folder)
                except Exception as e:
                    print(f"Error deleting {file_path}: {e}")

        # Delete all files in both folders
        delete_files_from_folder(generated_folder)
        delete_files_from_folder(original_folder)

        # Respond back to the client
        return JsonResponse({"message": "Images deleted successfully."}, status=200)


